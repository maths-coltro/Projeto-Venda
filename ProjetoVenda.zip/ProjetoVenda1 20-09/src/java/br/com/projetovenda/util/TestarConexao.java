package br.com.projetovenda.util;


public class TestarConexao {
    public static void main(String[] args) throws Exception {
        ConnectionFactory.conectar();
    }
}
